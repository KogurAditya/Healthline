<?php
function redirect($adr)
{
	header("Location: " . $adr);
}
?>